using UnityEngine;

/// <summary>
/// �����������±߽�һ����������٣�2D ������
/// ���ã�Assets/Scripts/Systems/Spawning/DespawnBelowCamera.cs
/// </summary>
public class DespawnBelowCamera : MonoBehaviour
{
    public Camera targetCamera;
    public float margin = 2f;
    public bool destroy = true;

    private void Update()
    {
        if (!targetCamera) targetCamera = Camera.main;
        if (!targetCamera) return;

        float bottomY = targetCamera.transform.position.y - targetCamera.orthographicSize;
        if (transform.position.y < bottomY - margin)
        {
            if (destroy) Destroy(gameObject);
            else gameObject.SetActive(false);
        }
    }
}
