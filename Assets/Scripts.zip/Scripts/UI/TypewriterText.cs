using UnityEngine;
using TMPro;
using System.Collections;

public class TypewriterText : MonoBehaviour
{
    [Header("ÿ���ֳ��ֵļ�����룩")]
    public float charInterval = 0.03f;

    [Header("�Ƿ��ڿ�ʼʱ�Զ�����")]
    public bool playOnAwake = false;

    private TextMeshProUGUI tmp;
    private Coroutine typingCoroutine;

    private void Awake()
    {
        tmp = GetComponent<TextMeshProUGUI>();
    }

    private void OnEnable()
    {
        if (playOnAwake && !string.IsNullOrEmpty(tmp.text))
        {
            Play(tmp.text);
        }
    }

    /// <summary>
    /// ���Ŵ���Ч��
    /// </summary>
    public void Play(string fullText)
    {
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        typingCoroutine = StartCoroutine(TypeRoutine(fullText));
    }

    private IEnumerator TypeRoutine(string fullText)
    {
        tmp.text = "";
        foreach (char c in fullText)
        {
            tmp.text += c;
            yield return new WaitForSeconds(charInterval);
        }
    }

    /// <summary>
    /// �������������ı�
    /// </summary>
    public void ShowAll(string fullText)
    {
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        tmp.text = fullText;
    }
}
