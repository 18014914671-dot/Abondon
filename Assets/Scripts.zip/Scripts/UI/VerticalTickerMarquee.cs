using UnityEngine;
using TMPro;

public class VerticalTickerMarquee : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private RectTransform maskArea;   // �ü�����TickerRoot��
    [SerializeField] private RectTransform textRect;   // �ı� RectTransform
    [SerializeField] private TextMeshProUGUI tmpText;

    [Header("Content")]
    [TextArea(3, 10)]
    [SerializeField]
    private string content =
        "ABONDON SYSTEM LOG\n" +
        "--------------------------------\n" +
        "Pilot connected...\n" +
        "Data recovered: 0x01\n" +
        "Navigation system online\n" +
        "Awaiting deployment...\n";

    [Header("Motion")]
    [SerializeField] private float speed = 40f; // ���� / ��
    [SerializeField] private float gap = 40f;   // �����ײ�����

    private float topSpawnY;
    private float bottomLimitY;

    private void Awake()
    {
        if (tmpText != null)
            tmpText.text = content;
    }

    private void Start()
    {
        Canvas.ForceUpdateCanvases();
        RecalculateBounds();
        PlaceAtTop();
    }

    private void Update()
    {
        if (textRect == null) return;

        // �����ƶ�
        textRect.anchoredPosition += Vector2.down * speed * Time.deltaTime;

        // ������������ȫ�����ײ�
        float textTopEdge = textRect.anchoredPosition.y;
        if (textTopEdge < bottomLimitY)
        {
            PlaceAtTop();
        }
    }

    private void RecalculateBounds()
    {
        if (maskArea == null || textRect == null) return;

        float maskHeight = maskArea.rect.height;

        topSpawnY = maskHeight + gap;
        bottomLimitY = -textRect.rect.height - gap;
    }

    private void PlaceAtTop()
    {
        textRect.anchoredPosition = new Vector2(
            textRect.anchoredPosition.x,
            topSpawnY
        );
    }

    // ��������ʱ�����ݣ����綯̬��־��
    public void SetContent(string newContent)
    {
        content = newContent;
        if (tmpText != null) tmpText.text = content;

        Canvas.ForceUpdateCanvases();
        RecalculateBounds();
        PlaceAtTop();
    }
}
