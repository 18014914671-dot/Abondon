using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class WordQuizFeedbackFX : MonoBehaviour
{
    [Header("Refs")]
    [Tooltip("���ڶ����� UI ���ڵ㣨������ Canvas �µ�ĳ�������������� HUDRoot��")]
    public RectTransform shakeRoot;

    [Tooltip("����ѡ�ť���� WordQuizManager �� optionButtons ��Ӧ��")]
    public Button[] optionButtons;

    [Header("Burst Prefabs (UI)")]
    [Tooltip("���ʱ�ڰ�ťλ�����ɵ� UI ��Ч Prefab��RectTransform��")]
    public RectTransform correctBurstPrefab;

    [Tooltip("���ʱ�ڰ�ťλ�����ɵ� UI ��Ч Prefab��RectTransform��")]
    public RectTransform wrongBurstPrefab;

    [Header("Timing")]
    public float lockDuration = 0.18f;      // ���ʱ������ס��ť������������
    public float buttonPunchScale = 1.10f;  // ��ť��ž��һ�µķ���
    public float buttonPunchTime = 0.10f;

    [Header("Shake")]
    public float shakeDuration = 0.12f;
    public float shakeStrength = 16f;       // UI ��������ǿ�ȣ�Խ��Խ����

    [Header("Tint (Optional)")]
    [Tooltip("��ť Image ��ɫ��һ�£��ɲ��")]
    public Color correctTint = new Color(0.4f, 1f, 0.9f, 1f);
    public Color wrongTint = new Color(1f, 0.35f, 0.35f, 1f);
    public float tintTime = 0.12f;

    private bool _busy;

    public void PlaySubmitFX(int chosenIndex, bool isCorrect)
    {
        if (_busy) return;
        if (optionButtons == null || chosenIndex < 0 || chosenIndex >= optionButtons.Length) return;

        StartCoroutine(Co_Play(chosenIndex, isCorrect));
    }

    private IEnumerator Co_Play(int chosenIndex, bool isCorrect)
    {
        _busy = true;

        // 1) ��ס��ťһС�ᣨ��ֹͬ֡����/������
        SetButtonsInteractable(false);

        // 2) ѡ�а�ť���壨scale punch��+ tint
        var btn = optionButtons[chosenIndex];
        if (btn != null)
        {
            var rt = btn.GetComponent<RectTransform>();
            if (rt != null) StartCoroutine(Co_Punch(rt, buttonPunchScale, buttonPunchTime));

            var img = btn.GetComponent<Image>();
            if (img != null) StartCoroutine(Co_Tint(img, isCorrect ? correctTint : wrongTint, tintTime));
        }

        // 3) Burst ��Ч��UI Prefab�������ڰ�ť����
        SpawnBurstAtButton(chosenIndex, isCorrect);

        // 4) UI �������� shakeRoot��
        if (shakeRoot != null) yield return Co_Shake(shakeRoot, shakeDuration, shakeStrength);
        else yield return new WaitForSeconds(shakeDuration);

        // 5) ����
        yield return new WaitForSeconds(Mathf.Max(0f, lockDuration - shakeDuration));
        SetButtonsInteractable(true);

        _busy = false;
    }

    private void SetButtonsInteractable(bool v)
    {
        if (optionButtons == null) return;
        foreach (var b in optionButtons)
        {
            if (b == null) continue;
            b.interactable = v;
        }
    }

    private IEnumerator Co_Punch(RectTransform rt, float scaleMul, float time)
    {
        if (rt == null) yield break;
        Vector3 baseScale = rt.localScale;
        Vector3 target = baseScale * scaleMul;

        float t = 0f;
        // ���ٷŴ�
        while (t < time)
        {
            t += Time.unscaledDeltaTime;
            float k = Mathf.Clamp01(t / time);
            rt.localScale = Vector3.Lerp(baseScale, target, EaseOutCubic(k));
            yield return null;
        }

        t = 0f;
        // ���ٻص�
        while (t < time)
        {
            t += Time.unscaledDeltaTime;
            float k = Mathf.Clamp01(t / time);
            rt.localScale = Vector3.Lerp(target, baseScale, EaseOutCubic(k));
            yield return null;
        }

        rt.localScale = baseScale;
    }

    private IEnumerator Co_Tint(Image img, Color flash, float time)
    {
        if (img == null) yield break;
        Color baseColor = img.color;

        float t = 0f;
        while (t < time)
        {
            t += Time.unscaledDeltaTime;
            float k = Mathf.Clamp01(t / time);
            img.color = Color.Lerp(baseColor, flash, EaseOutCubic(k));
            yield return null;
        }

        t = 0f;
        while (t < time)
        {
            t += Time.unscaledDeltaTime;
            float k = Mathf.Clamp01(t / time);
            img.color = Color.Lerp(flash, baseColor, EaseOutCubic(k));
            yield return null;
        }

        img.color = baseColor;
    }

    private IEnumerator Co_Shake(RectTransform target, float duration, float strength)
    {
        if (target == null) yield break;

        Vector2 basePos = target.anchoredPosition;
        float t = 0f;

        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            float k = 1f - Mathf.Clamp01(t / duration); // Խ��Խ��
            float x = (Random.value * 2f - 1f) * strength * k;
            float y = (Random.value * 2f - 1f) * strength * k;
            target.anchoredPosition = basePos + new Vector2(x, y);
            yield return null;
        }

        target.anchoredPosition = basePos;
    }

    private void SpawnBurstAtButton(int index, bool isCorrect)
    {
        RectTransform prefab = isCorrect ? correctBurstPrefab : wrongBurstPrefab;
        if (prefab == null) return;

        var btn = optionButtons[index];
        if (btn == null) return;

        RectTransform btnRT = btn.GetComponent<RectTransform>();
        if (btnRT == null) return;

        // ʵ������ͬһ�� Canvas �㼶�prefab �ĸ��ڵ��� shakeRoot �ĸ����� Canvas��
        Transform parent = shakeRoot != null ? shakeRoot : btnRT.root;
        RectTransform inst = Instantiate(prefab, parent);
        inst.gameObject.SetActive(true);

        // ����Ч�ŵ���ť���ģ�ͬһ Canvas ��������������뼴��
        inst.position = btnRT.position;

        // �Զ����٣������������
        Destroy(inst.gameObject, 1.5f);
    }

    private float EaseOutCubic(float x) => 1f - Mathf.Pow(1f - x, 3f);
}
