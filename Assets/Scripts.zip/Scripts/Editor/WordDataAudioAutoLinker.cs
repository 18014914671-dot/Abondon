// Assets/Editor/Abondon/WordDataAudioIndexLinker.cs
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.Video;

public class WordDataAudioIndexLinker : EditorWindow
{
    [Header("Folders")]
    [SerializeField] private DefaultAsset wordDataFolder;   // ���� Assets/Data/WordData/NGC9011
    [SerializeField] private DefaultAsset audioFolder;      // ���� Assets/Data/Video/NGC1 (��ͼ1��Ŀ¼)

    [Header("Options")]
    [SerializeField] private string audioFieldName = "audioClip"; // WordData��AudioClip�ֶε���ʵ������
    [SerializeField] private bool overwriteIfAlreadySet = false;  // �Ѿ�����Ƶʱ�Ƿ񸲸�
    [SerializeField] private bool alsoTryVideoClip = true;        // �����Ƶ��ʵ�����VideoClip��Ҳ����ƥ��

    [MenuItem("Tools/Abondon/Link WordData Audio By Index")]
    public static void Open()
    {
        GetWindow<WordDataAudioIndexLinker>("Link Audio By Index");
    }

    private void OnGUI()
    {
        GUILayout.Label("WordData <-> Audio auto linker (by index)", EditorStyles.boldLabel);

        wordDataFolder = (DefaultAsset)EditorGUILayout.ObjectField("WordData Folder", wordDataFolder, typeof(DefaultAsset), false);
        audioFolder = (DefaultAsset)EditorGUILayout.ObjectField("Audio Folder", audioFolder, typeof(DefaultAsset), false);

        EditorGUILayout.Space(6);

        audioFieldName = EditorGUILayout.TextField("WordData Audio Field Name", audioFieldName);
        overwriteIfAlreadySet = EditorGUILayout.Toggle("Overwrite If Already Set", overwriteIfAlreadySet);
        alsoTryVideoClip = EditorGUILayout.Toggle("Also Try VideoClip", alsoTryVideoClip);

        EditorGUILayout.Space(10);

        if (GUILayout.Button("Link Now"))
        {
            LinkNow();
        }

        EditorGUILayout.HelpBox(
            "ƥ�����\n" +
            "WordData �ʲ������� '1_cosmos'��ȡǰ������� 1 -> ��� '0001' ȥ��ƵĿ¼��ͬ���ļ���\n" +
            "��Ƶ�ļ��������� 4 λ���֣�0001/0002/...����",
            MessageType.Info
        );
    }

    private void LinkNow()
    {
        if (wordDataFolder == null || audioFolder == null)
        {
            EditorUtility.DisplayDialog("Missing", "����ѡ�� WordData Folder �� Audio Folder��", "OK");
            return;
        }

        string wordPath = AssetDatabase.GetAssetPath(wordDataFolder);
        string audioPath = AssetDatabase.GetAssetPath(audioFolder);

        if (!AssetDatabase.IsValidFolder(wordPath) || !AssetDatabase.IsValidFolder(audioPath))
        {
            EditorUtility.DisplayDialog("Invalid", "ѡ�Ĳ����ļ��С�", "OK");
            return;
        }

        // 1) ������ "0001" -> AudioClip/VideoClip ӳ��
        var audioMap = new Dictionary<string, UnityEngine.Object>(StringComparer.OrdinalIgnoreCase);

        // AudioClip
        foreach (var guid in AssetDatabase.FindAssets("t:AudioClip", new[] { audioPath }))
        {
            var p = AssetDatabase.GUIDToAssetPath(guid);
            var key = Path.GetFileNameWithoutExtension(p).Trim(); // 0001
            var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(p);
            if (clip != null && IsFourDigits(key))
                audioMap[key] = clip;
        }

        // VideoClip���������Щ�ļ���ʵ�� mp4 ����� VideoClip��
        if (alsoTryVideoClip)
        {
            foreach (var guid in AssetDatabase.FindAssets("t:VideoClip", new[] { audioPath }))
            {
                var p = AssetDatabase.GUIDToAssetPath(guid);
                var key = Path.GetFileNameWithoutExtension(p).Trim(); // 0001
                var clip = AssetDatabase.LoadAssetAtPath<VideoClip>(p);
                if (clip != null && IsFourDigits(key) && !audioMap.ContainsKey(key))
                    audioMap[key] = clip;
            }
        }

        // 2) ���� WordData ��д��
        var wordGuids = AssetDatabase.FindAssets("t:WordData", new[] { wordPath });

        int linked = 0, missing = 0, skipped = 0, overwritten = 0, badName = 0;

        Undo.IncrementCurrentGroup();
        int group = Undo.GetCurrentGroup();
        Undo.SetCurrentGroupName("Link WordData Audio By Index");

        foreach (var guid in wordGuids)
        {
            var assetPath = AssetDatabase.GUIDToAssetPath(guid);
            var wordAssetName = Path.GetFileNameWithoutExtension(assetPath); // 1_cosmos

            if (!TryGetLeadingIndex(wordAssetName, out int idx))
            {
                badName++;
                continue;
            }

            string key = idx.ToString("D4"); // 0001

            var word = AssetDatabase.LoadAssetAtPath<ScriptableObject>(assetPath);
            if (word == null) continue;

            var so = new SerializedObject(word);

            var audioProp = so.FindProperty(audioFieldName);
            if (audioProp == null || audioProp.propertyType != SerializedPropertyType.ObjectReference)
            {
                Debug.LogError($"[Linker] �Ҳ����ֶ� '{audioFieldName}' ���ֶβ��� ObjectReference��{assetPath}");
                skipped++;
                continue;
            }

            bool alreadySet = audioProp.objectReferenceValue != null;
            if (alreadySet && !overwriteIfAlreadySet)
            {
                skipped++;
                continue;
            }

            if (audioMap.TryGetValue(key, out var clipObj) && clipObj != null)
            {
                Undo.RecordObject(word, "Assign Clip");

                audioProp.objectReferenceValue = clipObj;
                so.ApplyModifiedPropertiesWithoutUndo();
                EditorUtility.SetDirty(word);

                if (alreadySet) overwritten++;
                else linked++;
            }
            else
            {
                missing++;
                Debug.LogWarning($"[MissingAudio] key={key}  WordData={wordAssetName}  path={assetPath}");
            }
        }

        Undo.CollapseUndoOperations(group);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        Debug.Log($"[Linker Done] linked={linked}, overwritten={overwritten}, missing={missing}, skipped={skipped}, badName={badName}");
        EditorUtility.DisplayDialog("Done",
            $"linked={linked}\n" +
            $"overwritten={overwritten}\n" +
            $"missing={missing}\n" +
            $"skipped={skipped}\n" +
            $"badName={badName}\n\n" +
            $"���鿴 Console��",
            "OK");
    }

    private static bool TryGetLeadingIndex(string assetName, out int index)
    {
        // ƥ�䣺 "1_cosmos" / "001_cosmos" / "12_xxx"
        // ȡ��ͷ��������
        var m = Regex.Match(assetName, @"^(\d+)");
        if (m.Success && int.TryParse(m.Groups[1].Value, out index))
            return true;

        index = -1;
        return false;
    }

    private static bool IsFourDigits(string s)
        => Regex.IsMatch(s, @"^\d{4}$");
}
#endif
